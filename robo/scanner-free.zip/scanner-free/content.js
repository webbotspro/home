(async function() {
    'use strict';

    const URL_CONFIG = "https://webbot.pro/mesas.json";
    let SELETORES = {};

    async function carregarConfig() {
        try {
            const response = await fetch(URL_CONFIG + "?t=" + new Date().getTime());
            SELETORES = await response.json();
            init();
        } catch (err) {
            console.error("❌ Erro ao carregar configurações.");
        }
    }

    carregarConfig();

    function init() {
        const Regras = {
            vermelho: (n) => [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(n),
            preto: (n) => n !== 0 && ![1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(n),
            par: (n) => n !== 0 && n % 2 === 0,
            impar: (n) => n % 2 !== 0,
            grande: (n) => n >= 19 && n <= 36,
            pequeno: (n) => n >= 1 && n <= 18,
            d1: (n) => n >= 1 && n <= 12,
            d2: (n) => n >= 13 && n <= 24,
            d3: (n) => n >= 25 && n <= 36,
            c1: (n) => n !== 0 && n % 3 === 1,
            c2: (n) => n !== 0 && n % 3 === 2,
            c3: (n) => n !== 0 && n % 3 === 0
        };

        const calcAusencia = (nums, fn) => {
            let c = 0;
            for (let n of nums) { if (!fn(n)) c++; else break; }
            return c;
        };

        const style = document.createElement('style');
        style.innerHTML = `
            #wb-top-center-wrap { position:fixed; top:6px; left:50%; transform:translateX(-50%); z-index:2147483647; pointer-events:none; }
            .wb-main-panel { position: fixed; top: 60px; right: 15px; z-index: 1000000; background: #111; border: 1px solid #28ffbb; padding: 12px; border-radius: 8px; color: white; width: 190px; font-family: Arial; }
            .wb-field { width: 100%; background: #222; color: #fff; border: 1px solid #444; margin: 5px 0 10px 0; padding: 6px; border-radius: 4px; font-size: 12px; }
            .wb-btn { width: 100%; background: #28ffbb; color: #000; border: none; padding: 10px; border-radius: 4px; font-weight: bold; cursor: pointer; }
            .wb-badge-fix { position: absolute !important; top: 5px !important; left: 5px !important; z-index: 2000 !important; background: #00ff00 !important; color: #000 !important; padding: 2px 8px; border-radius: 5px; font-weight: bold; font-size: 13px; pointer-events: none; border: 1px solid #fff; }
            #wb-internal-panel { position: fixed; top: 15px; left: 15px; z-index: 2147483640; background: rgba(0,0,0,0.85); border: 2px solid #28ffbb; padding: 10px; border-radius: 8px; font-family: Arial; color: white; min-width: 170px; display: none; }
            .wb-int-row { display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 13px; border-bottom: 1px solid #333; padding-bottom: 3px; }
            .wb-int-val { font-weight: bold; color: #28ffbb; }
            .wb-int-alert { color: #00ff00; text-shadow: 0 0 8px #00ff00; }
        `;
        document.head.appendChild(style);

        const header = document.createElement("div");
        header.id = "wb-top-center-wrap";
        header.innerHTML = `<div style="display:flex; align-items:center; gap:8px; background:rgba(0,0,0,.75); color:#fff; border:1px solid rgba(40,255,187,.6); border-radius:10px; padding:6px 15px; font-family:Arial; font-size:11px; font-weight:bold; backdrop-filter:blur(4px); pointer-events:auto;"><span style="color:#28ffbb;">WEBBOTS PRO</span><span style="width:1px; height:12px; background:rgba(255,255,255,0.2);"></span><span>STATUS: <span style="color:#28ffbb;">BOT GRATUITO</span></span></div>`;
        document.body.appendChild(header);

        const panel = document.createElement('div');
        panel.className = 'wb-main-panel';
        panel.innerHTML = `
            <div style="text-align:center; font-weight:bold; color:#28ffbb; margin-bottom:10px;">SCANNER FREE</div>
            <label style="font-size:10px;">AUSÊNCIA ALVO (1-9):</label>
            <select id="wb-alvo" class="wb-field">${Array.from({length: 9}, (_, i) => `<option value="${i+1}">${i+1} Rodadas</option>`).join('')}</select>
            <label style="font-size:10px;">ESTRATÉGIA:</label>
            <select id="wb-tipo" class="wb-field">
                <option value="duzias">Dúzias Completas</option>
                <option value="cor">Vermelho e Preto</option>
                <option value="paridade">Pares e Ímpares</option>
                <option value="colunas">Colunas Completas</option>
                <option value="tamanho">Grande e Pequeno</option>
            </select>
            <button id="wb-power" class="wb-btn">LIGAR SCANNER</button>
        `;
        document.body.appendChild(panel);

        const intPanel = document.createElement('div');
        intPanel.id = 'wb-internal-panel';
        document.body.appendChild(intPanel);

        let ativo = false;
        let loop = null;
        let estavaNaMesa = false; // Controle de estado

        function desligarScanner() {
            ativo = false;
            const btn = document.getElementById('wb-power');
            if(btn) {
                btn.innerText = "LIGAR SCANNER";
                btn.style.background = "#28ffbb";
                btn.style.color = "#000";
            }
        }

        function updateInternalPanel(nums, estrategia) {
            const alvo = parseInt(document.getElementById('wb-alvo').value);
            const titulos = {
                duzias: "DÚZIAS (AUSÊNCIAS)", cor: "COR (AUSÊNCIAS)",
                paridade: "PARIDADE (AUSÊNCIAS)", colunas: "COLUNAS (AUSÊNCIAS)",
                tamanho: "TAMANHO (AUSÊNCIAS)"
            };
            
            let htmlContent = `<div style="font-weight:bold; color:#28ffbb; border-bottom:1px solid #28ffbb; margin-bottom:8px; text-align:center;">${titulos[estrategia] || estrategia.toUpperCase()}</div>`;
            const renderRow = (label, val) => `<div class="wb-int-row"><span>${label}:</span> <span class="wb-int-val ${val >= alvo ? 'wb-int-alert' : ''}">${val}</span></div>`;

            if (estrategia === 'duzias') {
                htmlContent += renderRow("1ª Dúzia", calcAusencia(nums, Regras.d1));
                htmlContent += renderRow("2ª Dúzia", calcAusencia(nums, Regras.d2));
                htmlContent += renderRow("3ª Dúzia", calcAusencia(nums, Regras.d3));
            } else if (estrategia === 'cor') {
                htmlContent += renderRow("Vermelho", calcAusencia(nums, Regras.vermelho));
                htmlContent += renderRow("Preto", calcAusencia(nums, Regras.preto));
            } else if (estrategia === 'paridade') {
                htmlContent += renderRow("Pares", calcAusencia(nums, Regras.par));
                htmlContent += renderRow("Ímpares", calcAusencia(nums, Regras.impar));
            } else if (estrategia === 'colunas') {
                htmlContent += renderRow("1ª Coluna", calcAusencia(nums, Regras.c1));
                htmlContent += renderRow("2ª Coluna", calcAusencia(nums, Regras.c2));
                htmlContent += renderRow("3ª Coluna", calcAusencia(nums, Regras.c3));
            } else if (estrategia === 'tamanho') {
                htmlContent += renderRow("Grande", calcAusencia(nums, Regras.grande));
                htmlContent += renderRow("Pequeno", calcAusencia(nums, Regras.pequeno));
            }
            intPanel.innerHTML = htmlContent;
            intPanel.style.display = 'block';
        }

        function scan() {
            const isInsideTable = !!document.querySelector(SELETORES.MESA.BOTAO_FECHAR);
            const estrategiaAtual = document.getElementById('wb-tipo').value;
            
            if (isInsideTable) {
                estavaNaMesa = true; 
                const histInterno = document.querySelectorAll(SELETORES.MESA.HISTORICO_NUMEROS);
                const numsInternos = Array.from(histInterno).map(el => parseInt(el.innerText)).filter(n => !isNaN(n));
                if (numsInternos.length > 0) updateInternalPanel(numsInternos, estrategiaAtual);
                panel.style.display = 'none';
            } else {
                // SE ELE ACABOU DE SAIR DA MESA, DESLIGA O SCANNER
                if (estavaNaMesa) {
                    desligarScanner();
                    estavaNaMesa = false;
                }

                intPanel.style.display = 'none';
                panel.style.display = 'block';
                
                const mesas = document.querySelectorAll(SELETORES.MESA.CARD_MESA_LOBBY);
                const alvo = parseInt(document.getElementById('wb-alvo').value);

                mesas.forEach(mesa => {
                    const hist = mesa.querySelectorAll(SELETORES.MESA.HISTORICO_NUMEROS);
                    const nums = Array.from(hist).map(el => parseInt(el.innerText)).filter(n => !isNaN(n));
                    if (nums.length > 0) {
                        let a = 0;
                        if (estrategiaAtual === 'cor') a = Math.max(calcAusencia(nums, Regras.vermelho), calcAusencia(nums, Regras.preto));
                        else if (estrategiaAtual === 'paridade') a = Math.max(calcAusencia(nums, Regras.par), calcAusencia(nums, Regras.impar));
                        else if (estrategiaAtual === 'duzias') a = Math.max(calcAusencia(nums, Regras.d1), calcAusencia(nums, Regras.d2), calcAusencia(nums, Regras.d3));
                        else if (estrategiaAtual === 'colunas') a = Math.max(calcAusencia(nums, Regras.c1), calcAusencia(nums, Regras.c2), calcAusencia(nums, Regras.c3));
                        else if (estrategiaAtual === 'tamanho') a = Math.max(calcAusencia(nums, Regras.grande), calcAusencia(nums, Regras.pequeno));

                        if (getComputedStyle(mesa).position === 'static') mesa.style.position = 'relative';
                        let badge = mesa.querySelector('.wb-badge-fix');
                        if (!badge) { badge = document.createElement('div'); badge.className = 'wb-badge-fix'; mesa.appendChild(badge); }
                        badge.innerText = `AUS: ${a}`;

                        // SÓ CLICA SE O SCANNER ESTIVER ATIVO
                        if (ativo && a >= alvo) {
                            mesa.click();
                        }
                    }
                });
            }
        }

        document.getElementById('wb-power').addEventListener('click', function() {
            ativo = !ativo;
            this.innerText = ativo ? "DESLIGAR SCANNER" : "LIGAR SCANNER";
            this.style.background = ativo ? "#ff4444" : "#28ffbb";
            this.style.color = ativo ? "#fff" : "#000";
            if (ativo && !loop) loop = setInterval(scan, 1000);
        });

        // Inicia o monitoramento de estado (mesmo desligado ele atualiza badges)
        if(!loop) loop = setInterval(scan, 1000);
    }
})();